<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\AdminNotification;
use App\Models\Bid;
use App\Models\Category;
use App\Models\GeneralSetting;
use App\Models\Merchant;
use App\Models\Product;
use App\Models\Csvmodel;
use App\Models\Review;
use App\Models\Comment;
use App\Models\Gallery;
use App\Models\Transaction;
use Illuminate\Http\Request;
use App\Models\Galleryproduct;
class ProductController extends Controller
{

    public function __construct()
    {
        $this->activeTemplate = activeTemplate();
    }

    public function products()
    {
        $pageTitle      = request()->search_key?'Search Vehicles':'All Vehicle';
        $emptyMessage   = 'No vehicle found';
        $categories     = Category::with('products')->where('status', 1)->get();

        $products       = Product::live();
        $products       = $products->where('name', 'like', '%'.request()->search_key.'%')->with('category');
        $allProducts    = clone $products->get();
        if(request()->category_id){
            $products       = $products->where('category_id', request()->category_id);
        }
        $products = $products->paginate(getPaginate(18));

        $distinctYears = Csvmodel::distinct()->select('Year')->get();

        $distinctModels = Csvmodel::distinct()->select('Model')->get();
        $distinctMake = Csvmodel::distinct()->select('Make')->get();
        return view($this->activeTemplate.'product.list', compact('pageTitle', 'distinctYears','distinctModels', 'distinctMake' ,'emptyMessage', 'products', 'allProducts', 'categories'));
    }

    public function filter(Request $request, $selectedValue = null, $name_searching = null)
    {

        $pageTitle      = 'Search Vehicles';
        $emptyMessage   = 'No product found';
        // Start with a query for live products
        $products = Product::live();
  // Filter products by name if a search key is provided
        if ($request->has('search_key') && $request->input('search_key') != "" ) {
            $searchKey = $request->input('search_key');
            $products->where('name', 'like', '%' . $searchKey . '%');
        }
        // dd($selectedValue);
        // Check if $selectedValue is not empty or null
        if (isset($selectedValue) && $selectedValue != "") {
            // Filter products by Year, Model, or Make if a value is selected
            $products->where(function ($query) use ($selectedValue) {
                $query->where('Year', $selectedValue)
                    ->orWhere('Make', $selectedValue)
                    ->orWhere('Model',$selectedValue);
            });
            return response()->json([
                'products' => $products->paginate(getPaginate(18)),
                'code' => 'success',
            ]);
        }



        if($request->sorting){
            $products->orderBy($request->sorting, 'ASC');
        }
        if($request->categories){
            $products->whereIn('category_id', $request->categories);
        }
        if($request->minPrice){
            $products->where('price', '>=', $request->minPrice);
        }
        if($request->maxPrice){
            $products->where('price', '<=', $request->maxPrice);
        }

        $products = $products->paginate(getPaginate(18));

        return view($this->activeTemplate.'product.filtered', compact('pageTitle', 'emptyMessage', 'products'));
    }

    public function productDetails($id)
    {
        $pageTitle = 'Live Auction';
        $distinctYears = Csvmodel::distinct()->select('Year')->get();
        $distinctClass = Csvmodel::distinct()->select('Class')->get();
        $distinctModels = Csvmodel::distinct()->select('Model')->get();
        $distinctMake = Csvmodel::distinct()->select('Make')->get();
        $latestBid = Bid::where('product_id', $id)
        ->orderBy('created_at', 'desc')
        ->first();
        $highestBid = Bid::where('product_id', $id)
        ->orderByDesc('amount')
        ->first();

    if ($highestBid) {
        $userName = $highestBid->user->firstname;
    } else {
        $userName = "No Bids Yet"; // Handle the case where there are no bids.
    }
        $product = Product::with('reviews', 'merchant', 'bids.user', 'reviews.user')->where('status', '!=', 0)->findOrFail($id);
        $product_comments = Comment::with(['product', 'user'])->where('product_id', $id)

       ->get();

        $relatedProducts = Product::live()->where('category_id', $product->category_id)->where('id', '!=', $id)->limit(10)->get();

        $imageData      = imagePath()['product'];
        $seoContents    = getSeoContents($product, $imageData, 'image');
        $images = Gallery :: with(['product'])->where('product_id', $id)->get();
        return view($this->activeTemplate.'product.details', compact('pageTitle', 'userName','product','distinctYears','distinctClass','distinctModels','distinctMake','relatedProducts', 'seoContents', 'latestBid', 'product_comments', 'images'));
    }


    public function loadMore(Request $request)
    {
        $reviews = Review::where('product_id', $request->pid)->with('user')->latest()->paginate(5);

        return view($this->activeTemplate . 'partials.product_review', compact('reviews'));
    }

    public function bid(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|gt:0',
            'product_id' => 'required|integer|gt:0'
        ]);

        $product = Product::live()->with('merchant', 'admin')->findOrFail($request->product_id);

        $user = auth()->user();

        if($product->price > $request->amount){
            $notify[] = ['error', 'Bid amount must be greater than product price'];
            return back()->withNotify($notify);
        }

        if($request->amount > $user->balance){
            $notify[] = ['error', 'Insufficient Balance'];
            return back()->withNotify($notify);
        }

        $bid = Bid::where('product_id', $request->product_id)->where('user_id', $user->id)->exists();

        if($bid){
            $notify[] = ['error', 'You already bidden on this product'];
            return back()->withNotify($notify);
        }

        $bid = new Bid();
        $bid->product_id = $product->id;
        $bid->user_id = $user->id;
        $bid->amount = $request->amount;
        $bid->save();

        $product->total_bid += 1;
        $product->save();
        $user->balance -= $request->amount;
        $user->save();

        $general = GeneralSetting::first();

        $trx = getTrx();

        $transaction = new Transaction();
        $transaction->user_id = $user->id;
        $transaction->amount = $request->amount;
        $transaction->post_balance = $user->balance;
        $transaction->trx_type = '-';
        $transaction->details = 'Subtracted for a new bid';
        $transaction->trx = $trx;
        $transaction->save();

        if($product->admin){
            $adminNotification = new AdminNotification();
            $adminNotification->user_id = auth()->user()->id;
            $adminNotification->title = 'A user has been bidden on your product';
            $adminNotification->click_url = urlPath('admin.product.bids',$product->id);
            $adminNotification->save();

            $notify[] = ['success', 'Bidden successfully'];
            return back()->withNotify($notify);
        }

        $product->merchant->balance += $request->amount;
        $product->merchant->save();

        $transaction = new Transaction();
        $transaction->merchant_id = $product->merchant_id;
        $transaction->amount = $request->amount;
        $transaction->post_balance = $product->merchant->balance;
        $transaction->trx_type = '+';
        $transaction->details = showAmount($request->amount) . ' ' . $general->cur_text . ' Added for Bid';
        $transaction->trx =  $trx;
        $transaction->save();

        notify($product->merchant, 'BID_COMPLETE', [
            'trx' => $trx,
            'amount' => showAmount($request->amount),
            'currency' => $general->cur_text,
            'product' => $product->name,
            'product_price' => showAmount($product->price),
            'post_balance' => showAmount($product->merchant->balance),
        ], 'merchant');

        $notify[] = ['success', 'Bidden successfully'];
        return back()->withNotify($notify);

    }
    public function deleteImages($id)
    {
        // Delete the image with the given $id from the database
        $image = Galleryproduct::find($id);
        if ($image) {
            $image->delete();
            return response()->json(['success' => true]);
        } else {
            return response()->json(['success' => false]);
        }
    }
    public function saveProductReview(Request $request)
    {

        $request->validate([
            'rating' => 'required|integer|between:1,5',
            'product_id' => 'required|integer'
        ]);

        Bid::where('user_id', auth()->id())->where('product_id', $request->product_id)->firstOrFail();


        $review = Review::where('user_id', auth()->id())->where('product_id', $request->product_id)->first();
        $product = Product::find($request->product_id);

        if(!$review){
            $review = new Review();
            $product->total_rating += $request->rating;
            $product->review_count += 1;
            $notify[] = ['success', 'Review given successfully'];
        }else{
            $product->total_rating = $product->total_rating - $review->rating + $request->rating;
            $notify[] = ['success', 'Review updated successfully'];
        }

        $product->avg_rating = $product->total_rating / $product->review_count;
        $product->save();

        $review->rating = $request->rating;
        $review->description = $request->description;
        $review->user_id = auth()->id();
        $review->product_id = $request->product_id;
        $review->save();

        return back()->withNotify($notify);

    }

    public function saveMerchantReview(Request $request)
    {
        $request->validate([
            'rating' => 'required|integer|between:1,5',
            'merchant_id' => 'required|integer'
        ]);

        $merchant = Merchant::with('bids')->whereHas('bids', function($bid){
            $bid->where('user_id', auth()->id());
        })
        ->findOrFail($request->merchant_id);

        $review = Review::where('user_id', auth()->id())->where('merchant_id', $request->merchant_id)->first();

        if(!$review){
            $review = new Review();
            $merchant->total_rating += $request->rating;
            $merchant->review_count += 1;
            $notify[] = ['success', 'Review given successfully'];
        }else{
            $merchant->total_rating = $merchant->total_rating - $review->rating + $request->rating;
            $notify[] = ['success', 'Review updated successfully'];
        }

        $merchant->avg_rating = $merchant->total_rating / $merchant->review_count;
        $merchant->save();

        $review->rating = $request->rating;
        $review->description = $request->description;
        $review->user_id = auth()->id();
        $review->merchant_id = $request->merchant_id;
        $review->save();

        return back()->withNotify($notify);

    }
}
